import tushare as ts
import datetime

def stock_trend(code,now_time):
    code = str(code)
    # 获取前n天的数据：datetime.timedelta(days=-10)
    yes_time = now_time + datetime.timedelta(days=-10)
    y_time = yes_time.strftime('%Y-%m-%d')
    n_time = now_time.strftime('%Y-%m-%d')
    # 调取tushare数据：历史数据
    df = ts.get_hist_data(code,start=y_time,end=n_time)
    # 声明一个字符串,将所需数据一行一行拼接成字符串,并用&符号进行分割
    datastr=''
    # 循环获取数据，ix[][]通过行列获取数据
    for idx in df.index:
        rowstr = '\"\''+code+'\',%s,\'\',%s,%s,%s,%s,%s\"'%(idx,df.ix[idx]['open'],df.ix[idx]['high'],df.ix[idx]['low'],df.ix[idx]['close'],df.ix[idx]['volume'])
        datastr += rowstr + '&'
    datastr = datastr[:-1]
    return datastr

    # 方法二：使用pandas处理数据