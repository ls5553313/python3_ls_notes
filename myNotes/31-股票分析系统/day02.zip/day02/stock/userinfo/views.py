from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import login,logout,authenticate
import json
import logging
from django.core.exceptions import ObjectDoesNotExist
from .models import *
# Create your views here.


def register_(request):
    if request.method == "POST":
        new_user = UserInfo()
        new_user.username = request.POST.get('username','')
        if not new_user.username:
            return HttpResponse(json.dumps({'result':False,'data':'','error':'用户名不能为空'}))
        try:
            olduser = UserInfo.objects.filter(username=new_user.username)
            if olduser:
                return HttpResponse(json.dumps({'result':False,'data':'','error':'用户名重复'}))
        except ObjectDoesNotExist as e:
            logging.warning(e)
        if request.POST.get('pwd') != request.POST.get('cpwd'):
            return HttpResponse(json.dumps({'result': False, 'data': '', 'error': '两次密码输入不一致'}))
        # 使用django自带加密方法：make_password(明文,None,加密方法)
        new_user.password = make_password(request.POST.get('pwd'), None, 'pbkdf2_sha1')
        # 使用django自带密码验证：check_password()
        try:
            new_user.save()
            Fund.objects.create(user=new_user, money=0, frozen_money=0)
        except ObjectDoesNotExist as e:
            logging.warning(e)
        return HttpResponse(json.dumps({'result':True,'data':'注册成功','error':''}))


def login_(request):
    if request.method == "POST":
        username = request.POST.get('username','')
        password = request.POST.get('password','')
        if not username:
            return HttpResponse(json.dumps({'result': False, 'data': '', 'error': '用户名不能为空'}))
        # 使用django自带用户验证：authenticate（username,password）,返回结果该用户对象
        user = authenticate(username=username,password=password)
        if user is not None and user.isActive:
            # 使用django自带的登录方法：login(request,需要登录的用户)
            login(request,user)
            # 判断用户跳转过来的源链接地址，空为首页跳转，非空为其他详情页跳转
            url = request.COOKIES.get('source_url','')
            return HttpResponse(json.dumps({'result':True,'data':{'url':url,'username':username},'error':''}))
        else:
            return HttpResponse(json.dumps({'result':False,'data':'','error':'用户名密码错误'}))


def logout_(request):
    # 使用django自带logout(request)登出操作
    logout(request)
    return HttpResponse({'result':True,'data':'用户已登出','error':''})










